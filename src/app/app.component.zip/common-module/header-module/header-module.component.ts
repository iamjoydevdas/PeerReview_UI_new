import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'peer-header',
  templateUrl: './header-module.component.html',
  styleUrls: ['./header-module.component.css']
})
export class HeaderModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
