export class Error{
    errorCode:number;
    errorMessage:string;
}