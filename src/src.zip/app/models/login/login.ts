export class Login{
    userName: number;
    password: string;
}